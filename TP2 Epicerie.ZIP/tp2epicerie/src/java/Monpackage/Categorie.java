/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Monpackage;

import java.util.ArrayList;

/**
 *
 * @author Odile Kouame
 */
public class Categorie {
     public ArrayList<Produit> listproduit;
     public int idcat;
    public String nomcat;
    public String imgcat;

    public Categorie(ArrayList<Produit> listproduit, String nomcat) {
        this.listproduit = listproduit;
        this.nomcat = nomcat;
    }

    public Categorie(int idcat, String nomcat, String imgcat) {
        this.idcat = idcat;
        this.nomcat = nomcat;
        this.imgcat = imgcat;
    }

    public ArrayList<Produit> getListproduit() {
        return listproduit;
    }

    public void setListproduit(ArrayList<Produit> listproduit) {
        this.listproduit = listproduit;
    }

    public int getIdcat() {
        return idcat;
    }

    public void setIdcat(int idcat) {
        this.idcat = idcat;
    }

    public String getNomcat() {
        return nomcat;
    }

    public void setNomcat(String nomcat) {
        this.nomcat = nomcat;
    }

    public String getImgcat() {
        return imgcat;
    }

    public void setImgcat(String imgcat) {
        this.imgcat = imgcat;
    }
    
    
    
}
