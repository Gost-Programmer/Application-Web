/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Monpackage;

import java.util.ArrayList;

/**
 *
 * @author Odile Kouame
 */
public class Panier {
     int total;
    private ArrayList<Produit> listProduit;
    
     public Panier()
    {
    this.listProduit= new ArrayList<Produit>();
    }

    public Panier(ArrayList<Produit> listProduit) {
        this.listProduit = listProduit;
    }

    public ArrayList<Produit> getListProduit() {
        return listProduit;
    }

    public void setListProduit(ArrayList<Produit> listProduit) {
        this.listProduit = listProduit;
    }
    
    
    
    public void addProduit(Produit p)
    {
        this.listProduit.add(p);
    }
    
    public void removeProduit(Produit p)
    {
       this.listProduit.remove(p);
       
    }
    
    public void updateProduit(Produit p,int qte)
    {
        
    }
    
    public void clearPanier()
    {
     this.listProduit.clear();
    }
    
    public double totalPanier()
    {
        return this.total;
        
    }
    
    public ArrayList<Produit>showPanier()
    {
        return this.listProduit;
    }
    
    
    
}
