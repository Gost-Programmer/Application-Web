/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Monpackage;

import java.util.ArrayList;

/**
 *
 * @author Odile Kouame
 */
public class Produit {
    
     public int idprod;
    public String nomprod;
    public Double prix;
    public int qte;
    public String imgprod;
     public ArrayList list;

    public Produit(String nomprod, Double prix, int qte, String imgprod, ArrayList list) {
        this.nomprod = nomprod;
        this.prix = prix;
        this.qte = qte;
        this.imgprod = imgprod;
        this.list = list;
    }

    public Produit(int idprod, String nomprod, Double prix, int qte, String imgprod, ArrayList list) {
        this.idprod = idprod;
        this.nomprod = nomprod;
        this.prix = prix;
        this.qte = qte;
        this.imgprod = imgprod;
        this.list = list;
    }

    public int getIdprod() {
        return idprod;
    }

    public void setIdprod(int idprod) {
        this.idprod = idprod;
    }

    public String getNomprod() {
        return nomprod;
    }

    public void setNomprod(String nomprod) {
        this.nomprod = nomprod;
    }

    public Double getPrix() {
        return prix;
    }

    public void setPrix(Double prix) {
        this.prix = prix;
    }

    public int getQte() {
        return qte;
    }

    public void setQte(int qte) {
        this.qte = qte;
    }

    public String getImgprod() {
        return imgprod;
    }

    public void setImgprod(String imgprod) {
        this.imgprod = imgprod;
    }

    public ArrayList getList() {
        return list;
    }

    public void setList(ArrayList list) {
        this.list = list;
    }
     
     
    
}
